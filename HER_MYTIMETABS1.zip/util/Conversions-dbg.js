/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.declare("publicservices.her.mytimetable.s1.util.Conversions");
jQuery.sap.require("sap.ui.core.format.DateFormat");
publicservices.her.mytimetable.s1.util.Conversions = {

	formatDate : function(date) {
		if (date) {
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern : "HH:mm"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var timeStr = timeFormat.format(new Date(date.ms + TZOffsetMs));
			return timeStr;
		}
	},
	formatTime : function(sVal1,sVal2) {
		if (sVal1 && sVal2) {
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern : "HH:mm"
			});
			var TZOffsetMs = new Date(0).getTimezoneOffset() * 60 * 1000;
			var sStarttimeStr = timeFormat.format(new Date(sVal1.ms + TZOffsetMs));
			if(sVal2)
			var sEndtimeStr = timeFormat.format(new Date(sVal2.ms + TZOffsetMs));
			return sStarttimeStr+" "+"-"+" "+sEndtimeStr;
		}
	},
	setDateNTime: function(sVal1){
		if(sVal1){
			var dateTimeFormatter = sap.ui.core.format.DateFormat.getDateInstance({style : 'full'});
			var dateText = dateTimeFormatter.format(sVal1);
			return dateText;
		}
	},
	setInstructor : function(sVal1) {
		if (sVal1) {
			this.setVisible(true);
			this.setActive(true);
			return sVal1;
		} else {
			this.setVisible(false);
			return "";
		}
	},

	setEvntStatus: function(sVal1,sVal2){
		if(sVal1 && sVal2 !=null){
			if(sVal2){
				this.setState("Error");
				var oCan = sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('TXT_CANCELLED_LBL');
				return oCan+":"+" "+sVal1;
			}else{								
				this.setState("None");
				return sVal1;
			}
	}},
	setDetailStatus: function(sVal){
		if (sVal) {			
			var oCan = sap.ca.scfld.md.app.Application.getImpl()
			.getResourceBundle().getText('TXT_CANCELLED_LBL');			
	this.setState("Error");
	return oCan;
		} else {			
			var oOpen = sap.ca.scfld.md.app.Application.getImpl()
			.getResourceBundle().getText('TXT_ATTND');			
	this.setState("Success");
	return oOpen;
			
		}
	},
	getCredits : function(sVal) {
        if (sVal != null && sVal) {
               return Math.round(sVal);
        }
 },

 setNoDataText : function(sVal){
	 if(sVal){
		 return sVal;
		 
	 }else{
		 return sap.ca.scfld.md.app.Application.getImpl().getResourceBundle().getText('NO_DATA');	
	 }
 },
 setPlace: function(sVal1,sVal2,sVal3){
	 if(sVal1){
		 return sVal1+"  "+sVal2+"  "+sVal3;
	 }
 }
};