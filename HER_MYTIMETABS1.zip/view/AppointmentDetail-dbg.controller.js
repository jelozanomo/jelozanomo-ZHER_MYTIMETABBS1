/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.require("sap.ca.ui.quickoverview.EmployeeLaunch");
jQuery.sap.require("sap.ca.ui.quickoverview.CompanyLaunch");
jQuery.sap.require("publicservices.her.mytimetable.s1.util.Conversions");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.message.message");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("publicservices.her.mytimetable.s1.view.AppointmentDetail", {
	createdFromAccounts : false,
	
	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created. Can be used to
	 * modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 */
	onInit : function() {		
		this.ocal = '';
		this.oModel = this.oApplicationFacade.getODataModel();
		this.getView().setModel(this.oModel);
		this.oBundle = this.oApplicationFacade.getResourceBundle();
		// navigation call back
		this.oRouter.attachRouteMatched(function(oEvent) {
			if (oEvent.getParameter("name") === "detail") {
			var ModuleId = oEvent.getParameter("arguments").oModId;
			var EventId = oEvent.getParameter("arguments").oEvtId;
			var EventDate = oEvent.getParameter("arguments").oEvtDate;
			var that = this;
			this.ocal =oEvent.getParameter("arguments").ocal;
			var oCtxt = "/EventDetailSet(ModuleId='"+ModuleId+"',EventId='"+EventId+"',EventDate=datetime'"+EventDate+"')";		
			this.oModel.createBindingContext(oCtxt,function(oContext) {			
				that.getView().setBindingContext(oContext);
				that.onDataReceived();
		}, true);
			}
		}, this);
	},
	onDataReceived : function() {
		var oAttnds = this.getView().getBindingContext().getObject().Attendees;
		var oAttnArray = oAttnds.split(";");
		var oRes = [];
		var i;
		for (i = 0; i < oAttnArray.length-1; i++) {							
				var tmp ={ "oInsName" : oAttnArray[i]};										
				oRes.push(tmp);						
		}
		
		var out=[];
		var rout=[];
		
		if(oRes.length <= 10){
			 var oModelTable = new sap.ui.model.json.JSONModel();
				oModelTable.setData({"Attnds":oRes});
				this.byId('attendsId').setModel(oModelTable,'AddStud');
				this.byId('attendsId1').setVisible(false);
		}else{
			this.byId('attendsId1').setVisible(true);
			for(i=0;i<=Math.round((oRes.length/2)-1);i++){
		    	out.push(oRes[i]);
		    }
		    var oModelTable = new sap.ui.model.json.JSONModel();
			oModelTable.setData({"Attnds":out});
			this.byId('attendsId').setModel(oModelTable,'AddStud');	
			
		    for(i=Math.round((oRes.length/2));i<oRes.length;i++){
		    	rout.push(oRes[i]);
		    }		    
		    var oModelTable1 = new sap.ui.model.json.JSONModel();
			oModelTable1.setData({"Attnds":rout});			
		    this.byId('attendsId1').setModel(oModelTable1,'AddStud');	
		    
			/* for(i=0;i<=Math.round((oRes.length/3)-1);i++){
		    	out.push(oRes[i]);
		    }
		    var oModelTable = new sap.ui.model.json.JSONModel();
			oModelTable.setData({"Attnds":out});
			this.byId('attendsId').setModel(oModelTable,'AddStud');	
			
		    for(i=Math.round((oRes.length/3));i<Math.round((oRes.length/3)+(oRes.length/3));i++){
		    	rout.push(oRes[i]);
		    }		    
		    var oModelTable1 = new sap.ui.model.json.JSONModel();
			oModelTable1.setData({"Attnds":rout});			
		    this.byId('attendsId1').setModel(oModelTable1,'AddStud');	
		    
		    for(i=Math.round((oRes.length/3)+(oRes.length/3));i<oRes.length;i++){
		    	sout.push(oRes[i]);
		    }		    
		    var oModelTable1 = new sap.ui.model.json.JSONModel();
			oModelTable1.setData({"Attnds":sout});			
		    this.byId('attendsId2').setModel(oModelTable1,'AddStud');*/
		}
		    
		var oStatus = this.getView().getBindingContext().getObject().Status;
		if(oStatus){
			this.byId('statusBtnId').setVisible(false);
		}else{
			this.byId('statusBtnId').setVisible(true);
		}
	},
	onBack : function() {		
		var  oDateFrom = this.getView().getBindingContext().getObject().EventDate;		
		//var sDate = this.getDateParameterfromDate(oDateFrom);
		var sDate = oDateFrom.toISOString();
		if(this.ocal == 'W'){
			this.oRouter.navTo("week", {Date: sDate}, true);
		}else{
			this.oRouter.navTo("month", {Date: sDate}, true);
		}
		
	},
	onInsClick: function(oEvt){
		var oControl = oEvt.getSource();
		jQuery.sap.require("sap.ca.ui.quickoverview.Quickoverview");
    	var sSubViewName = "publicservices.her.mytimetable.s1.fragments.Employee";
    	var oIntrID = oEvt.getSource().getBindingContext().getObject().ContactId;
		if(oIntrID!=undefined){
			var fnBindContextToInstructor = jQuery.proxy(function(oQVView, oSubView){
				oQVView.bindElement("/ContactDetailSet('" + oIntrID + "')");
	    	},this);    	
	    	var oQVConfig = {
	                title : this.oBundle.getText("PROFESSOR"),
	                headerTitle : "{Name}",
	                headerSubTitle : "{Designation}\n{Department}",
	                subViewName : sSubViewName,
	                headerImgURL : "{PhotoUri}",
	                oModel : this.oApplicationFacade.getODataModel(), 
	                afterQvConfigured : fnBindContextToInstructor,
	                popoverHeight : '32em',
	        }; 
	        var oQuickoverview = new sap.ca.ui.quickoverview.Quickoverview(oQVConfig);
	        oQuickoverview.openBy(oControl);
		} 
	},
	getDateParameterfromDate : function(d) {
		// format: Date --> yyymmdd
		var sDay = d.getDate().toString();
		sDay = (sDay.length === 1) ? "0" + sDay : sDay;
		var sMonth = d.getMonth() + 1; // Months are zero based
		sMonth = sMonth.toString();
		sMonth = (sMonth.length === 1) ? "0" + sMonth : sMonth;
		var sYear = d.getFullYear();
		var sDate = "" + sYear + sMonth + sDay;
		return sDate;
	},
	onStatusClick: function(oEvent){
		if (sap.ushell.Container){
			var oBindingCtx = this.getView().getBindingContext().getObject();
			var oStat = oBindingCtx.StatusInd;
			var oAcadSess = oBindingCtx.AcademicSession;
			var oAcadYear = oBindingCtx.AcademicYear;
			var oPtype = oBindingCtx.ProgramType;
			var oPStdyId = oBindingCtx.ProgramOfStudyID;
			var oCrsId = oBindingCtx.ModuleId;
			var oCNav = sap.ushell.Container.getService("CrossApplicationNavigation");
			if(oStat){							
				oCNav.toExternal({target: {semanticObject: "AcademicCourse", action: "register"}, params: { CourseId: oCrsId, ProgramStudyId: oPStdyId, ProgType: oPtype,AcademicSession : oAcadSess, AcademicYear : oAcadYear, TileType : 'NAV' }});
			}else{
				oCNav.toExternal({target: {semanticObject: "CompetencyEvidence", action: "display"}, params: { CourseId: oCrsId, ProgramStudyId: oPStdyId, ProgType: oPtype,AcademicSession : oAcadSess, AcademicYear : oAcadYear, TileType : 'NAV' }});
			}			
			
		}
	}
	
/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered (NOT before the
 * first rendering! onInit() is used for that one!).
 */
// onBeforeRendering : function() {
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the
 * HTML could be done here. This hook is the same one that SAPUI5 controls get after being rendered.
 */
// onAfterRendering : function() {
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
 */
// onExit: function() {
//
// }
});