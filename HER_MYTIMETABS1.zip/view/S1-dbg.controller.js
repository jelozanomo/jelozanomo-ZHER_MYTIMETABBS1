/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.require("publicservices.her.mytimetable.s1.util.Conversions");
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");

sap.ca.scfld.md.controller.BaseFullscreenController.extend("publicservices.her.mytimetable.s1.view.S1", {
    onInit : function() {
    	sap.ca.scfld.md.controller.BaseFullscreenController.prototype.onInit.call(this);
    	this.oResBundle = this.oApplicationFacade.getResourceBundle();
    	this.calendarType = "W"; // calendar type W=week, M=month, D=day
		this.oFooterBar = this.byId("master_footer");
		this.bIsPhone = sap.ui.Device.system.phone;
		this.bIsTablet = sap.ui.Device.system.tablet;
		sap.ca.scfld.md.Startup.init('publicservices.her.mytimetable.s1', this);		
    	this.oModel = this.oApplicationFacade.getODataModel();
    	this.oList = this.byId("l");
    	this.oCal = this.byId("cal");
    	var oi18n = sap.m.getLocaleData();
    	this.oCLegend = this.byId('calLegId');
    	this.oPage = this.byId('appointmentListPage');
    	this.oCal.setMonths(oi18n.getMonths("wide"));
    	this.oBundle = this.oApplicationFacade.getResourceBundle();
		this.oScroll = this.byId("scroll");
		this.byId('calLegId').getAggregation('icon').setVisible(false);
		this.setScrollSize();
		this.osbtnTimeSwitch = this.byId("sbtnTimeSwitch");  	
		this.filterDate = new Date(new Date().toDateString()); // today without time
		this.oCal.toggleDatesSelection([this.filterDate], true);	
		this.oCal.rerender();
		this.defineButtons();
		if(this.bIsPhone || this.bIsTablet){
			this.byId('mobileLayoutId').setVisible(true);
			this.byId('desktopLayoutId').setVisible(false);
			this.oCLegend.setVisible(false);
			}else{
				this.byId('mobileLayoutId').setVisible(false);
				this.byId('desktopLayoutId').setVisible(true);
				this.oCLegend.setVisible(true);
			}
		this.oRouter.attachRouteMatched(function(oEvent) {
			if(this.bIsPhone || this.bIsTablet){
				if(oEvent.getParameter("name") == 'fullscreen'){
					if(oEvent.getParameter("arguments").Date){
						this.filterDate = oEvent.getParameter("arguments").Date;
					}
					this.osbtnTimeSwitch.setSelectedButton(this.byId("btnWeek").getId());
					this.onDisplayWeek();
					//this.oCal.rerender();
					this.getAppointmentList();
					this.oPage.setEnableScrolling(true);
					this.oList.setVisible(true);
				}
				if(oEvent.getParameter("name") == 'week'){
					if(oEvent.getParameter("arguments").Date){
						this.filterDate = oEvent.getParameter("arguments").Date;
					}
					this.osbtnTimeSwitch.setSelectedButton(this.byId("btnWeek").getId());
					this.onDisplayWeek();
					//this.oCal.rerender();
					this.getAppointmentList();
					this.oPage.setEnableScrolling(true);
					this.oList.setVisible(true);
				}
				if(oEvent.getParameter("name") == 'month' || oEvent.getParameter("name") == 'month_phone'){
					if(oEvent.getParameter("arguments").Date){
						this.filterDate = oEvent.getParameter("arguments").Date;
					}
					this.osbtnTimeSwitch.setSelectedButton(this.byId("btnMonth").getId());
					this.onDisplayMonth();
					//this.oCal.rerender();
					this.getAppointmentList();
					this.oPage.setEnableScrolling(true);
					this.oList.setVisible(true);
				}
			}else{
				if(oEvent.getParameter("name") == 'fullscreen'){
					if(oEvent.getParameter("arguments").Date){
						this.filterDate = oEvent.getParameter("arguments").Date;
					}
					this.osbtnTimeSwitch.setSelectedButton(this.byId("btnWeek").getId());
					this.onDisplayWeek();
					//this.oCal.rerender();
					this.getAppointmentList();
					this.oPage.setEnableScrolling(false);
					
				}
				if(oEvent.getParameter("name") == 'week'){
					if(oEvent.getParameter("arguments").Date){
						this.filterDate = oEvent.getParameter("arguments").Date;
					}
					this.osbtnTimeSwitch.setSelectedButton(this.byId("btnWeek").getId());
					this.onDisplayWeek();
					//this.oCal.rerender();
					this.getAppointmentList();
					this.oPage.setEnableScrolling(false);
					
				}
				if(oEvent.getParameter("name") == 'month'){
					if(oEvent.getParameter("arguments").Date){
						this.filterDate = oEvent.getParameter("arguments").Date;
					}
					this.osbtnTimeSwitch.setSelectedButton(this.byId("btnMonth").getId());
					this.onDisplayMonth();
					//this.oCal.rerender();
					this.getAppointmentList();
					this.oPage.setEnableScrolling(false);
					
				}
			}						
			}, this); 
		this.oList.attachUpdateFinished(function(a,b,c){
			if (this.oList.getBinding("items").getContexts().length && this.oModel.getProperty(this.oList.getBinding("items").getContexts()[0].getPath()).ReturnMessage) {
				var dialog = new sap.m.Dialog({
					title: this.oBundle.getText("LBL_WARN"),
					type: "Message",
					state: "Warning",
					content: new sap.m.Text({
						text: this.oModel.getProperty(this.oList.getBinding("items").getContexts()[0].getPath()).ReturnMessage
					}),
					endButton: new sap.m.Button({
						text: this.oBundle.getText("MSG_OK"),
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			}
			var oDate = new Date(this.filterDate);
			this.oCal.toggleDatesSelection([this.filterDate], true);
			this.setScrollSize();
			this.scrollToDate(oDate, this);			
		},this);
		/*this.oHeaderFooterOptions = {
			onBack: jQuery.proxy(function() {
				window.history.go(-1);
			}, this)
		};
		this.setHeaderFooterOptions(this.oHeaderFooterOptions);*/
    },

    onNavBack: function(){
    	window.history.go(-1);
    },

    getDateString : function(d) {
		var sDay = d.getDate().toString();
		sDay = (sDay.length === 1) ? "0" + sDay : sDay;
		var sMonth = d.getMonth() + 1; // Months are zero based
		sMonth = sMonth.toString();
		sMonth = (sMonth.length === 1) ? "0" + sMonth : sMonth;
		var sYear = d.getFullYear();
		// Safari browser: The pattern yyyy-MM-dd isn't an officially supported format for Date constructor but yyyy/MM/dd
		var sDate = sYear + "/" + sMonth + "/" + sDay;
		return sDate;
	},
	// Displaying an Appointment
	onAppointmentClicked : function(oEvt) {
		var myDate = new Date(oEvt.getSource().getBindingContext().getObject().EventDate);
		this.filterDate = myDate;
        var today = new Date(myDate);
        var oMonth = today.getMonth()+1;
        var dateString = today.getFullYear()+"-"+oMonth+"-"+today.getDate();		
		this.oRouter.navTo("detail", {
			oModId : ""+oEvt.getSource().getBindingContext().getObject().ModuleId,
			oEvtId : ""+oEvt.getSource().getBindingContext().getObject().EventId,
			oEvtDate: ""+myDate.toISOString().split("Z")[0],
			ocal : ""+this.calendarType
		},true);
	},
    getAppointmentList : function() {
		var oListItem = this.byId("AppListItem");
		this.oList.removeItem(oListItem);
		var aFilter = this.getViewFilters();
		var that = this;
		var oDateSorter = new sap.ui.model.Sorter("EventDate", false, function(oContext) {			
			var sDate = oContext.getProperty("EventDate");				
			if (typeof sDate === "string") {
				// for mock data
				sDate = sDate.replace("/Date(", "").replace(")/", "");
				var iDate = parseInt(sDate);
				sDate = new Date(iDate);						
			} 			
			var dtformatter = sap.ui.core.format.DateFormat.getDateInstance({
				style : "full"
			});
			return {
				key : that.getDateString(sDate),
				text : dtformatter.format(sDate)
			};
		});

		// delete all markers in calendar
		this.oCal.removeTypesOfAllDates(); 
		
		this.oList.bindAggregation("items", {
			path : "/EventListSet",
			template : oListItem,
			length: 500,
			sorter : oDateSorter,
			filters : aFilter,
			groupHeaderFactory : function(oGroup) {
				var header = new sap.m.GroupHeaderListItem({
					title : oGroup.text
				});
				if (oGroup.key === that.getDateString(new Date())) {
					// add style for todays group header
					header.addStyleClass("sapMLabelBold");
				}
				// mark day in calendar
				that.oCal.toggleDatesType([oGroup.key], "Type06", true);
				header.setUpperCase(false);
				return header;
			}
		});
		
	},
 // returns relevant filters for the appointment list
	getViewFilters : function() {
		var aDateFilter = [];
		var cal = this.byId("cal");
		var sDate = cal.getCurrentDate();
		var oSelDate = new Date(sDate);
		var oDateFrom = new Date(sDate);
		var oDateTo = new Date(sDate);
		var iDayIndex = oSelDate.getDay(); // 0 Sun, 1 Mon....
		if (this.calendarType == "W") {
			// week mode
			var iOffset = cal.getFirstDayOffset(); // 0 sunday
			var iOffsetFrom = iDayIndex - iOffset;
			var iOffsetTo = 7 - iOffsetFrom; // 7 days a week
			oDateFrom.setDate(oSelDate.getDate() - iOffsetFrom);
			oDateTo.setDate(oSelDate.getDate() + iOffsetTo); // weekslot
			// minus 1 sec
			oDateTo.setTime(oDateTo.getTime() - 1);
			this.calFromRange = oDateFrom;
			this.calToRange = oDateTo;
		} else if (this.calendarType == "M") {
			// month mode
			var year = oSelDate.getFullYear();
			var month = oSelDate.getMonth();
			oDateFrom = new Date(year, month, 2);
			oDateTo = new Date(year, month + 1, 1); // 1 month + 1 day
			oDateTo.setTime(oDateTo.getTime() - 1); // minus 1 sec
			this.calFromRange = oDateFrom;
			this.calToRange = oDateTo;
		} else if (this.calendarType == "D") {
			// day mode --- just show first selected date
			var sSelection = this.oCal.getSelectedDates()[0];
			if (!sSelection) {
				sSelection = cal.getCurrentDate();
			}
			var oSelection = new Date(sSelection);
			oDateFrom = oSelection;
			oDateTo = oSelection;
			oDateTo.setDate(oDateTo.getDate() + 1); // 1 day
			oDateTo.setTime(oDateTo.getTime() - 1); // minus 1 sec
			this.calFromRange = oSelection;
			this.calToRange = oSelection;
		}
		var oFilter;
		oFilter = new sap.ui.model.odata.Filter("EventDate", [{
			operator : "BT",
			value1 : oDateFrom,
			value2 : oDateTo
		}]);
			aDateFilter.push(oFilter);
		return aDateFilter;
	},
	onDateRangeChanged: function(oEvt){
		var tmp;
	},
	scrollToDate : function(date, that) {		
		  var dateTimeFormatter = sap.ui.core.format.DateFormat.getDateInstance({style : 'full'});
		  var dateText = dateTimeFormatter.format(date);
		  var items = that.oList.getItems();
		  var start = 0;
		  var end = 0;
		  var bFound = false;
		  if (items[0]) {
		  	start = items[0].getDomRef().getBoundingClientRect().top;
		  }
		  for(var i = 0; i < items.length; i++){		  
		      if(!items[i].getBindingContext()){
		    	 items[i].removeStyleClass("sapMLabelBold");
			     if( items[i].getTitle() === dateText){
			      bFound = true;
		          end  = items[i].getDomRef().getBoundingClientRect().top;
		          items[i].addStyleClass("sapMLabelBold");
		       }			     
		      }		  
		  }
		  if(bFound){
		  that.byId('scroll').scrollTo(0,that.modulus(start - end),500);
		}		
	},
	modulus : function(number){
		 if(number < 0){
		   return -number;
		 }
		return number;
		},
	onDateClicked: function(oEvent){
		if (this.calendarType == "D") {
			this.getAppointmentList();
		}
		if (this.bIsPhone && this.calendarType == "M") {
			var oClickDate = new Date(oEvent.getParameter("date"));
			this.oCal.setCurrentDate(oClickDate);
			this._buttonDisplayWeek();
			return;
		}
		if (this.calendarType !== "D") {
			// scroll to day in list
			var oClickDate = new Date(oEvent.getParameter("date"));
			
			if (oEvent.getSource().getSelectedDates.length == 0) {
				this.oCal.toggleDatesSelection([oClickDate], true);
			}
			this.scrollToDate(oClickDate, this);
		}
	},
	onCurrentDateChanged: function(oEvt){
		this.getAppointmentList();
		this.oCal.toggleDatesSelection(this.oCal.getSelectedDates(), false);
	},
	// button click: calendar in Week View
	_buttonDisplayWeek : function() {
	
		this.calendarType = 'W';
		this.filterDate = this.oCal.getSelectedDates()[0];
		var sDate;
		// try to get selected day
		if (this.oCal.getSelectedDates().length > 0) {
			sDate = this.getDateParameterfromDate(new Date(this.oCal.getSelectedDates()[0]));
		} else {
			// indicator _ for not to mark day in target view
			sDate = "_" + this.getDateParameterfromDate(this.calFromRange);
		}
		this.onDisplayWeek(null);
		// navigate
		if (!this.filterAccountID) {
			this.oRouter.navTo("week", {
				Date : sDate
			});
		}
	},
	// button click: calendar in Month View
	_buttonDisplayMonth : function() {
		this.calendarType = 'M';
		this.filterDate = this.oCal.getSelectedDates()[0];
		var sDate;
		// try to get selected day
		if (this.oCal.getSelectedDates().length > 0) {
			sDate = this.getDateParameterfromDate(new Date(this.oCal.getSelectedDates()[0]));
		} else {
		// indicator _ for not to mark day in target view
			sDate = "_" + this.getDateParameterfromDate(this.calToRange);
		}
		this.onDisplayMonth(null);
		// navigate
		if (this.bIsPhone) {
			if (!this.filterAccountID) {
				this.oRouter.navTo("month_phone", {
					Date : sDate
				});
			}
		} else {
			if (!this.filterAccountID) {
				this.oRouter.navTo("month", {
					Date : sDate
				});
			} 
		}
	},
	onTodayClick : function(targetDate) {
		// today without timepart
		var now;
		if (targetDate) {
			now = targetDate;
		} else {
			now = new Date(new Date().toDateString());
		}

		if (now < this.calFromRange || this.calToRange < now) {
			// load data --> date/now is not loaded
			this.getAppointmentList();
			//up-port
			this.bTodayClicked = true;
		}
		else{
			// simulate tap on todays day to scroll
			this.oCal.fireTapOnDate({
				didSelect : true,
				date : now
			});
			
		}
		this.filterDate = now;
	},
	// /////////////////////////////////////////////

	onDisplayMonth : function(oEvent) {
		this.oCal.setMonthsPerRow(1);
		this.oCal.setWeeksPerRow(1);
		this.oCal.setSingleRow(false);
		this.oCal.setVisible(true);
		this.calendarType = "M";
		this.oCal.setSwipeToNavigate(true);
		this.oCal.unselectAllDates();
			
	},

	onDisplayDay : function(oEvent) {
		this.oCal.setMonthsPerRow(1);
		this.oCal.setWeeksPerRow(1);
		this.oCal.setSingleRow(true);
		this.oCal.setVisible(true);
		this.calendarType = "D";
		this.oCal.setSwipeToNavigate(true);
		this.oCal.unselectAllDates();
	},
	onDisplayWeek : function(oEvent) {
		this.oCal.setMonthsPerRow(1);
		this.oCal.setWeeksPerRow(1);
		this.oCal.setSingleRow(true);
		this.oCal.setVisible(true);
		this.calendarType = "W";
		this.oCal.setSwipeToNavigate(true);
		this.oCal.unselectAllDates();
	},
	getDateParameterfromDate : function(d) {
		// format: Date --> yyymmdd
		var sDay = d.getDate().toString();
		sDay = (sDay.length === 1) ? "0" + sDay : sDay;
		var sMonth = d.getMonth() + 1; // Months are zero based
		sMonth = sMonth.toString();
		sMonth = (sMonth.length === 1) ? "0" + sMonth : sMonth;
		var sYear = d.getFullYear();
		var sDate = "" + sYear + sMonth + sDay;
		return sDate;
	},
	defineButtons : function() {
		this.oFooterBar.destroyContentLeft();
		// add todays button manually because settings button shall be most left button
		var oBtnToday;
		if (this.bIsPhone) {
			oBtnToday = new sap.m.Button({
				press : jQuery.proxy(this._buttonToday, this),
				icon : "sap-icon://appointment-2"
			});
		} else {
			oBtnToday = new sap.m.Button({
				press : jQuery.proxy(this._buttonToday, this),
				text : this.oResBundle.getText("TXT_TODAY")
			});

		}
		this.oFooterBar.addContentLeft(oBtnToday);
		//this.byId("btnAdd").setIcon("sap-icon://action");		
	},
	_buttonToday : function() {
		this.oCal.setCurrentDate(new Date()); // navigate to todays month/week
		this.oCal.unselectAllDates();
		this.oCal.toggleDatesSelection([new Date()], true); // mark day as
		// selected
		this.onTodayClick(); // load data
	},
	setScrollSize : function() {
		// correct size for startup
		var pFooterRef = this.oFooterBar.getDomRef();
		//var pCalRef = this.oCal.getDomRef();
		var pCalRef='';
		if(this.bIsPhone){
			pCalRef = this.oCal.getDomRef();
		
		}else{
			 pCalRef = this.byId('calLegId').getDomRef();
		}

		if (pFooterRef && pCalRef) {
			var posFooter = pFooterRef.getBoundingClientRect();
			var posCal = pCalRef.getBoundingClientRect();
			var size = (posFooter.top - posCal.bottom);
			var sSize = "" + size + "px";
			if (size > 0 && sSize != this.oScroll.getHeight()) {
				this.oScroll.setHeight(sSize);
				jQuery.sap.log.info("### Set scroll size   ### size -- " + size);
				this.oScroll.rerender();
			}
		}
	},
});