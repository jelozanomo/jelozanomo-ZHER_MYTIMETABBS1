/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("publicservices.her.mytimetable.s1.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");
jQuery.sap.require("sap.ca.scfld.md.app.Application");

sap.ca.scfld.md.ConfigurationBase.extend("publicservices.her.mytimetable.s1.Configuration", {

	oServiceParams: {
		serviceList: [
			{
				name: "PIQ_EVENT_TIMETABLE_SRV",
				 masterCollection: "ProductCollection",
				serviceUrl: publicservices.her.mytimetable.s1.Component.getMetadata().getManifestEntry("sap.app").dataSources["PIQ_EVENT_TIMETABLE_SRV"].uri, //oData service relative path
				isDefault: true,
				mockedDataSource: jQuery.sap.getModulePath("publicservices.her.mytimetable.s1") + "/" + publicservices.her.mytimetable.s1.Component.getMetadata().getManifestEntry("sap.app").dataSources["PIQ_EVENT_TIMETABLE_SRV"].settings.localUri
			}
		]
	},

	getServiceParams: function () {
		return this.oServiceParams;
	},

	getAppConfig: function() {
		return this.oAppConfig;
	},

	/**
	 * @inherit
	 */
	getServiceList: function () {
		return this.oServiceParams.serviceList;
	},

	getMasterKeyAttributes: function () {
		return ["Id"];
	}

});