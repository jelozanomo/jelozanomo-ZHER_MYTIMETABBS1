/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
// define a root UIComponent which exposes the main view
jQuery.sap.declare("publicservices.her.mytimetable.s1.Component");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");

// extent of sap.ca.scfld.md.ComponentBase
sap.ca.scfld.md.ComponentBase.extend("publicservices.her.mytimetable.s1.Component", {
	metadata : sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
		// "name": "Fullscreen Sample",
		// "version" : "6.0.5",
		// "library" : "publicservices.her.mytimetable.s1",
		// "includes" : [],
		// "dependencies" : {
		// 	"libs" : ["sap.m", "sap.me"],
		// 	"components" : [],
		// },
		"manifest": "json",
		viewPath : "publicservices.her.mytimetable.s1.view",
		fullScreenPageRoutes : {
			// fill the routes to your full screen pages in here.
			"fullscreen" : {
				"pattern" : "",
				"view" : "S1"
			},
		"month" : {
			pattern : "month/{Date}",
			view : "S1",
			"viewLevel" : 1
		},
		"month_phone" : {
			pattern : "month_p/{Date}",
			view : "S1",
			"viewLevel" : 1
		},
		"week" : {
			pattern : "week/{Date}",
			view : "S1",
			"viewLevel" : 1
		},"detail" : {
			pattern : "detail/{oModId}/{oEvtId}/{oEvtDate}/{ocal}",
			view : "AppointmentDetail",
			"viewLevel" : 2
		}
		},
	}),	

	/**
	 * Initialize the application
	 * 
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {
		var oViewData = {component: this};
		return sap.ui.view({
			viewName : "publicservices.her.mytimetable.s1.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		});
	}
});