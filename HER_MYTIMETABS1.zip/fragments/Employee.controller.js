/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.controller("publicservices.her.mytimetable.s1.fragments.Employee",{handleTelPress:function(e){sap.m.URLHelper.triggerTel(e.getSource().getText());},handleEmailPress:function(e){sap.m.URLHelper.triggerEmail(e.getSource().getText());}});
