/*
 * Copyright (C) 2009-2018 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.controller("publicservices.her.mytimetable.s1.fragments.Employee", {
	handleTelPress: function (oEvt) {
	    sap.m.URLHelper.triggerTel(oEvt.getSource().getText());
	  },
	  handleEmailPress : function(oEvt){
		  sap.m.URLHelper.triggerEmail(oEvt.getSource().getText());
	  }
});